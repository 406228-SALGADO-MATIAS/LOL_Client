package LoL_Client_Back.models.reference;

import lombok.Data;

@Data
public class ProfileIcon {
    private Long id;
    private String icon;
}
