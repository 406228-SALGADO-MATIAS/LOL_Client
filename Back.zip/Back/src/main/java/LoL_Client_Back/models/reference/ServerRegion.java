package LoL_Client_Back.models.reference;

import lombok.Data;

@Data
public class ServerRegion {
    private Long id;
    private String server;
}
