package LoL_Client_Back.models.reference;

import lombok.Data;

@Data
public class ChampionStyle {
    private Long id;
    private String style;
}
