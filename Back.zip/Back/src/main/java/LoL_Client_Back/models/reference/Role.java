package LoL_Client_Back.models.reference;

import lombok.Data;

@Data
public class Role {
    private Long id;
    private String role;
}
