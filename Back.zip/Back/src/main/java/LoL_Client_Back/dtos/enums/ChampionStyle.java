package LoL_Client_Back.dtos.enums;

public enum ChampionStyle {
    Fighter,Marksman,Mage,Assassin,Tank,Support
}
