package LoL_Client_Back.dtos.enums;

public enum UserRankTier {
    Unranked,Bronze, Silver, Gold, Platinum, Emerald,
    Diamond,Master,Grandmaster,Challenger
}
