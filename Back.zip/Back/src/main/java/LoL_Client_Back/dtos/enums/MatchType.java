package LoL_Client_Back.dtos.enums;

public enum MatchType {
    RANKED, NORMAL, ARAM
}
