package LoL_Client_Back.dtos.enums;

public enum ChampionRole {
    TOP, JUNGLE, MID , ADC, SUPPORT
}
