package LoL_Client_Back.dtos.enums;

public enum ChampionDifficulty {
    Easy,Medium,Hard
}
